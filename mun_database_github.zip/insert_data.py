import pandas as pd
import mysql.connector

# --- EDIT THESE BEFORE RUNNING ---
DB_HOST = "localhost"
DB_USER = "root"
DB_PASS = "your_password"
DB_NAME = "mun_database"
CSV_PATH = "delegates.csv"
# -------------------------------

# Connect to MySQL
conn = mysql.connector.connect(
    host=DB_HOST,
    user=DB_USER,
    password=DB_PASS
)
cursor = conn.cursor()

# Create database if not exists
cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
cursor.execute(f"USE {DB_NAME}")

# Run SQL schema
with open("create_table.sql", "r") as f:
    cursor.execute(f.read(), multi=True)

# Load CSV
df = pd.read_csv(CSV_PATH)

# Insert data
for _, row in df.iterrows():
    cursor.execute("""
        INSERT INTO delegates (ID, Name, School, Age, MUNs, Committee, Portfolio1, Portfolio2, BD, HC, SM, HM, VM)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, tuple(row))

conn.commit()
conn.close()
print("✅ Data imported successfully!")
