CREATE TABLE IF NOT EXISTS delegates (
    ID INT PRIMARY KEY,
    Name VARCHAR(100),
    School VARCHAR(100),
    Age INT,
    MUNs INT,
    Committee VARCHAR(50),
    Portfolio1 VARCHAR(100),
    Portfolio2 VARCHAR(100),
    BD INT,
    HC INT,
    SM INT,
    HM INT,
    VM INT
);
